package com.example.accelerometersensorapp;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.graphics.Color;
import androidx.appcompat.app.AppCompatActivity;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private TextView accelerometerValuesTextView;
    private TextView accelerometerDataTextView;
    private SQLiteOpenHelper dbHelper;
    private SQLiteDatabase db;
    private BarChart barChart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        accelerometerValuesTextView = findViewById(R.id.accelerometerValuesTextView);
        accelerometerDataTextView = findViewById(R.id.accelerometerDataTextView);
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        dbHelper = new DatabaseHelper(this);

        Button showDatabaseButton = findViewById(R.id.showDatabaseButton);
        showDatabaseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayAccelerometerData();
            }
        });

        barChart = findViewById(R.id.barChart);

        Button visualizeXButton = findViewById(R.id.showXDataButton);
        visualizeXButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                visualizeData("x_axis");
            }
        });

        Button visualizeYButton = findViewById(R.id.showYDataButton);
        visualizeYButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                visualizeData("y_axis");
            }
        });

        Button visualizeZButton = findViewById(R.id.showZDataButton);
        visualizeZButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                visualizeData("z_axis");
            }
        });

        // Enable user interaction
        barChart.setTouchEnabled(true);
        barChart.setPinchZoom(true);
        barChart.setDragEnabled(true);
        barChart.setScaleEnabled(true);
        barChart.setDrawGridBackground(false);

        displayAccelerometerData();
    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            float xAxis = event.values[0];
            float yAxis = event.values[1];
            float zAxis = event.values[2];

            // Insert accelerometer data into SQLite database
            insertAccelerometerData(xAxis, yAxis, zAxis);

            // Update TextView with current accelerometer values
            String accelerometerValues = "X: " + xAxis + "\nY: " + yAxis + "\nZ: " + zAxis;
            accelerometerValuesTextView.setText(accelerometerValues);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Not needed for this example
    }

    private void displayAccelerometerData() {
        db = dbHelper.getReadableDatabase();
        if (db != null) {
            Cursor cursor = db.rawQuery("SELECT * FROM accelerometer_data ORDER BY timestamp DESC", null);
            if (cursor != null) {
                StringBuilder dataBuilder = new StringBuilder();
                if (cursor.moveToFirst()) {
                    int idIndex = cursor.getColumnIndex("_id");
                    int timestampIndex = cursor.getColumnIndex("timestamp");
                    int xAxisIndex = cursor.getColumnIndex("x_axis");
                    int yAxisIndex = cursor.getColumnIndex("y_axis");
                    int zAxisIndex = cursor.getColumnIndex("z_axis");

                    do {
                        long id = cursor.getLong(idIndex);
                        String timestamp = cursor.getString(timestampIndex);
                        float xAxis = cursor.getFloat(xAxisIndex);
                        float yAxis = cursor.getFloat(yAxisIndex);
                        float zAxis = cursor.getFloat(zAxisIndex);

                        dataBuilder.append("ID: ").append(id).append(", Timestamp: ").append(timestamp)
                                .append(", X: ").append(xAxis).append(", Y: ").append(yAxis).append(", Z: ").append(zAxis)
                                .append("\n");
                    } while (cursor.moveToNext());
                } else {
                    dataBuilder.append("No data available.");
                }
                cursor.close();

                accelerometerDataTextView.setText(dataBuilder.toString());
            }
            db.close();
        }
    }

    private void visualizeData(String axis) {
        List<BarEntry> entries = new ArrayList<>();
        db = dbHelper.getReadableDatabase();
        if (db != null) {
            String query = "SELECT * FROM accelerometer_data ORDER BY timestamp DESC";
            Cursor cursor = db.rawQuery(query, null);
            if (cursor != null) {
                int index = 0;
                int axisIndex = cursor.getColumnIndex(axis);
                while (cursor.moveToNext()) {
                    float value = cursor.getFloat(axisIndex);
                    entries.add(new BarEntry(index++, value));
                }
                cursor.close();
            }
            db.close();
        }

        BarDataSet dataSet = new BarDataSet(entries, axis + " Data");
        dataSet.setColor(Color.RED);
        dataSet.setValueTextColor(Color.BLACK);
        BarData barData = new BarData(dataSet);

        barChart.setData(barData);
        barChart.invalidate();
    }

    private void insertAccelerometerData(float xAxis, float yAxis, float zAxis) {
        db = dbHelper.getWritableDatabase();
        if (db != null) {
            db.execSQL("INSERT INTO accelerometer_data (x_axis, y_axis, z_axis) VALUES (?, ?, ?)",
                    new Object[]{xAxis, yAxis, zAxis});
            db.close();
        }
    }

    private static class DatabaseHelper extends SQLiteOpenHelper {
        private static final String DATABASE_NAME = "accelerometer_data.db";
        private static final int DATABASE_VERSION = 1;

        DatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE IF NOT EXISTS accelerometer_data (_id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP, x_axis REAL, y_axis REAL, z_axis REAL)");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // Handle database upgrade if needed
        }
    }
}
