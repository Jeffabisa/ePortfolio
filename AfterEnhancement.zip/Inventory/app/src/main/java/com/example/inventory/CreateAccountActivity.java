package com.example.inventory;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class CreateAccountActivity extends AppCompatActivity {

    private static final String TAG = "CreateAccountActivity";
    private String generatedCode;
    private Map<String, Long> codeTimestamps = new HashMap<>();
    private static final long CODE_EXPIRY_DURATION = 5 * 60 * 1000; // 5 minutes
    private static final int MAX_ATTEMPTS = 3;
    private int failedAttempts = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.createaccountactivity);

        EditText firstNameEditText = findViewById(R.id.firstNameEditText);
        EditText lastNameEditText = findViewById(R.id.lastNameEditText);
        EditText usernameEditText = findViewById(R.id.usernameEditText);
        EditText passwordEditText = findViewById(R.id.passwordEditText);
        EditText confirmPasswordEditText = findViewById(R.id.confirmPasswordEditText);
        Spinner userRoleSpinner = findViewById(R.id.userRoleSpinner);
        EditText confirmationCodeEditText = findViewById(R.id.confirmationCodeEditText);
        Button requestCodeButton = findViewById(R.id.requestCodeButton);
        Button createAccountButton = findViewById(R.id.createAccountButton);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.user_roles, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        userRoleSpinner.setAdapter(adapter);

        requestCodeButton.setOnClickListener(v -> {
            String email = usernameEditText.getText().toString().trim();
            if (email.isEmpty()) {
                Toast.makeText(this, "Please enter your email to request a code", Toast.LENGTH_SHORT).show();
                return;
            }
            generatedCode = sendConfirmationCode(email);
            Toast.makeText(this, "Confirmation code sent to your email", Toast.LENGTH_SHORT).show();
            Log.d(TAG, "Generated confirmation code: " + generatedCode); // Log the code for testing
            // Optionally, display the code in a Toast (for testing only)
            Toast.makeText(this, "Generated code: " + generatedCode, Toast.LENGTH_LONG).show();
        });

        createAccountButton.setOnClickListener(v -> {
            String firstName = firstNameEditText.getText().toString().trim();
            String lastName = lastNameEditText.getText().toString().trim();
            String username = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();
            String confirmPassword = confirmPasswordEditText.getText().toString().trim();
            String userRole = userRoleSpinner.getSelectedItem().toString();
            String confirmationCode = confirmationCodeEditText.getText().toString().trim();

            if (firstName.isEmpty() || lastName.isEmpty() || username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || confirmationCode.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!password.equals(confirmPassword)) {
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!confirmationCode.equals(generatedCode)) {
                failedAttempts++;
                if (failedAttempts >= MAX_ATTEMPTS) {
                    Toast.makeText(this, "Too many failed attempts. Try again later.", Toast.LENGTH_SHORT).show();
                    return;
                }
                Toast.makeText(this, "Invalid confirmation code", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!isCodeValid(confirmationCode)) {
                Toast.makeText(this, "Confirmation code expired", Toast.LENGTH_SHORT).show();
                return;
            }

            addUserToDatabase(firstName, lastName, username, password, userRole);
        });
    }

    private String sendConfirmationCode(String email) {
        String code = generateRandomCode();
        long timestamp = System.currentTimeMillis();
        codeTimestamps.put(code, timestamp);
        // Simulate sending the code to the user's email
        Log.d(TAG, "Generated confirmation code: " + code + " for email: " + email);
        return code;
    }

    private String generateRandomCode() {
        Random random = new Random();
        int code = 100000 + random.nextInt(900000); // Generate a 6-digit random code
        return String.valueOf(code);
    }

    private boolean isCodeValid(String code) {
        Long timestamp = codeTimestamps.get(code);
        if (timestamp == null) {
            return false;
        }
        long currentTime = System.currentTimeMillis();
        return currentTime - timestamp <= CODE_EXPIRY_DURATION;
    }

    private void addUserToDatabase(String firstName, String lastName, String username, String password, String userRole) {
        try (DatabaseHelper dbHelper = new DatabaseHelper(this)) {
            long result = dbHelper.addUser(firstName, lastName, username, password, userRole);

            if (result != -1) {
                Toast.makeText(this, "Account created successfully", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(CreateAccountActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(this, "Failed to create account", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e(TAG, "Exception occurred", e);
        }
    }
}
