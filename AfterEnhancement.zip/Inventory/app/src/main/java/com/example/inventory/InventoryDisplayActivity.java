package com.example.inventory;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;

import java.util.List;

public class InventoryDisplayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_display);

        try (DatabaseHelper dbHelper = new DatabaseHelper(this)) {
            ListView listViewInventory = findViewById(R.id.listViewInventory);

            // Retrieve inventory data from the database
            List<InventoryItem> inventoryItems = dbHelper.getAllInventoryItems();

            // Initialize adapter with context and inventory items
            InventoryAdapter adapter = new InventoryAdapter(this, inventoryItems);
            listViewInventory.setAdapter(adapter);

            // Add button to go to InventoryActivity
            Button goToDataActivityButton = findViewById(R.id.goToDataActivityButton);
            goToDataActivityButton.setOnClickListener(v -> {
                Intent intent = new Intent(InventoryDisplayActivity.this, InventoryActivity.class);
                startActivity(intent);
            });

        } catch (Exception e) {
            // Handle any exceptions here by logging them
            Log.e("InventoryDisplayActivity", "Exception occurred", e);
        }

    }
}
