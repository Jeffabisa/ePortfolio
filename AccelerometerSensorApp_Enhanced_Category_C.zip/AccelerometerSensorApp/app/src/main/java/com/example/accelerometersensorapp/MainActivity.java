package com.example.accelerometersensorapp;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private TextView accelerometerValuesTextView;
    private TextView accelerometerDataTextView; // TextView to display database content
    private SQLiteOpenHelper dbHelper;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        accelerometerValuesTextView = findViewById(R.id.accelerometerValuesTextView);
        accelerometerDataTextView = findViewById(R.id.accelerometerDataTextView); // Initialize TextView
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        dbHelper = new DatabaseHelper(this);

        Button showDatabaseButton = findViewById(R.id.showDatabaseButton); // Button to show database content
        showDatabaseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayAccelerometerData(); // Display database content when button is clicked
            }
        });

        // Call the method to display accelerometer data
        displayAccelerometerData();
    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            float xAxis = event.values[0];
            float yAxis = event.values[1];
            float zAxis = event.values[2];

            // Insert accelerometer data into SQLite database
            insertAccelerometerData(xAxis, yAxis, zAxis);

            // Update TextView with current accelerometer values
            String accelerometerValues = "X: " + xAxis + "\nY: " + yAxis + "\nZ: " + zAxis;
            accelerometerValuesTextView.setText(accelerometerValues);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Not needed for this example
    }

    // Method to display database content in TextView
    private void displayAccelerometerData() {
        db = dbHelper.getReadableDatabase();
        if (db != null) {
            Cursor cursor = db.rawQuery("SELECT * FROM accelerometer_data ORDER BY timestamp DESC", null);
            if (cursor != null) {
                StringBuilder dataBuilder = new StringBuilder();
                if (cursor.moveToFirst()) {
                    // Retrieve column indices
                    int idIndex = cursor.getColumnIndex("_id");
                    int timestampIndex = cursor.getColumnIndex("timestamp");
                    int xAxisIndex = cursor.getColumnIndex("x_axis");
                    int yAxisIndex = cursor.getColumnIndex("y_axis");
                    int zAxisIndex = cursor.getColumnIndex("z_axis");

                    do {
                        long id = cursor.getLong(idIndex);
                        String timestamp = cursor.getString(timestampIndex);
                        float xAxis = cursor.getFloat(xAxisIndex);
                        float yAxis = cursor.getFloat(yAxisIndex);
                        float zAxis = cursor.getFloat(zAxisIndex);

                        // Append data to StringBuilder
                        dataBuilder.append("ID: ").append(id).append(", Timestamp: ").append(timestamp)
                                .append(", X: ").append(xAxis).append(", Y: ").append(yAxis).append(", Z: ").append(zAxis)
                                .append("\n");
                    } while (cursor.moveToNext());
                } else {
                    dataBuilder.append("No data available.");
                }
                cursor.close();

                // Display data in the TextView
                accelerometerDataTextView.setText(dataBuilder.toString());
            }
            db.close(); // Close the database connection
        }
    }

    // Pseudocode for inserting accelerometer data into SQLite database
    private void insertAccelerometerData(float xAxis, float yAxis, float zAxis) {
        db = dbHelper.getWritableDatabase();
        if (db != null) {
            db.execSQL("INSERT INTO accelerometer_data (x_axis, y_axis, z_axis) VALUES (?, ?, ?)",
                    new Object[]{xAxis, yAxis, zAxis});
            db.close();
        }
    }

    // SQLiteOpenHelper for managing database creation and version management
    private static class DatabaseHelper extends SQLiteOpenHelper {
        private static final String DATABASE_NAME = "accelerometer_data.db";
        private static final int DATABASE_VERSION = 1;

        DatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE IF NOT EXISTS accelerometer_data (_id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP, x_axis REAL, y_axis REAL, z_axis REAL)");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // Handle database upgrade if needed
        }
    }
}
