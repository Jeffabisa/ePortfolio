package com.example.inventory;

public class InventoryItem {
    private int id;
    private String name;
    private String description;
    private String category;
    private int quantityAvailable;
    private int quantityReserved;
    private String location;
    private double unitPrice;

    // Constructors
    public InventoryItem() {
        // Default constructor
    }

    public InventoryItem(int id, String name, String description, String category, int quantityAvailable, int quantityReserved, String location, double unitPrice) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.category = category;
        this.quantityAvailable = quantityAvailable;
        this.quantityReserved = quantityReserved;
        this.location = location;
        this.unitPrice = unitPrice;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getQuantityAvailable() {
        return quantityAvailable;
    }

    public void setQuantityAvailable(int quantityAvailable) {
        this.quantityAvailable = quantityAvailable;
    }

    public int getQuantityReserved() {
        return quantityReserved;
    }

    public void setQuantityReserved(int quantityReserved) {
        this.quantityReserved = quantityReserved;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }
}

