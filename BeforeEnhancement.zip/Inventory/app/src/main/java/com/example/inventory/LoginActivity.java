package com.example.inventory;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private static final String TAG = "LoginActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        try (DatabaseHelper db = new DatabaseHelper(this)) {
            EditText usernameEditText = findViewById(R.id.usernameEditText);
            EditText passwordEditText = findViewById(R.id.passwordEditText);
            Button loginButton = findViewById(R.id.loginButton);
            Button createAccountButton = findViewById(R.id.createAccountButton);

            loginButton.setOnClickListener(v -> {
                String username = usernameEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();
                if (db.checkUser(username, password)) {
                    // Start the InventoryDisplayActivity upon successful login
                    Intent intent = new Intent(LoginActivity.this, InventoryDisplayActivity.class);
                    startActivity(intent);
                    // Finish the current activity to prevent the user from going back to the login screen
                    finish();
                    Toast.makeText(LoginActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(LoginActivity.this, "Invalid Username or Password", Toast.LENGTH_SHORT).show();
                }
            });

            createAccountButton.setOnClickListener(v -> {
                // Start the CreateAccountActivity when the user clicks on the "Create Account" button
                Intent intent = new Intent(LoginActivity.this, CreateAccountActivity.class);
                startActivity(intent);
            });
        } catch (Exception e) {
            // Log the exception
            Log.e(TAG, "Exception occurred", e);
            // Handle the exception further if necessary
        }
    }
}
