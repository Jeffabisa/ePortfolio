package com.example.inventory;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

// Importing DatabaseHelper from the correct package

public class InventoryActivity extends AppCompatActivity {

    private EditText itemIdEditText, itemNameEditText, descriptionEditText, categoryEditText;
    private EditText quantityAvailableEditText, quantityReservedEditText, locationEditText, unitPriceEditText;
    private Button addDataButton, deleteDataButton;

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);  // Make sure this matches your XML file name

        // Initialize the DatabaseHelper
        dbHelper = new DatabaseHelper(this);

        // Initialize UI components
        initViews();

        // Setup button listeners
        setupListeners();
    }

    private void initViews() {
        itemIdEditText = findViewById(R.id.itemIdEditText);
        itemNameEditText = findViewById(R.id.itemNameEditText);
        descriptionEditText = findViewById(R.id.descriptionEditText);
        categoryEditText = findViewById(R.id.categoryEditText);
        quantityAvailableEditText = findViewById(R.id.quantityAvailableEditText);
        quantityReservedEditText = findViewById(R.id.quantityReservedEditText);
        locationEditText = findViewById(R.id.locationEditText);
        unitPriceEditText = findViewById(R.id.unitPriceEditText);
        addDataButton = findViewById(R.id.addDataButton);
        deleteDataButton = findViewById(R.id.deleteDataButton);
    }

    private void setupListeners() {
        addDataButton.setOnClickListener(v -> addItem());
        deleteDataButton.setOnClickListener(v -> deleteItem());
    }

    private void addItem() {
        // Collect data from EditText fields
        String name = itemNameEditText.getText().toString().trim();
        String description = descriptionEditText.getText().toString().trim();
        String category = categoryEditText.getText().toString().trim();
        int quantityAvailable = Integer.parseInt(quantityAvailableEditText.getText().toString().trim());
        int quantityReserved = Integer.parseInt(quantityReservedEditText.getText().toString().trim());
        String location = locationEditText.getText().toString().trim();
        double unitPrice = Double.parseDouble(unitPriceEditText.getText().toString().trim());

        // Insert data into the database
        // Call the modified addItem method with additional parameters
        dbHelper.addItem(name, description, category, quantityAvailable, quantityReserved, location, unitPrice);
        Toast.makeText(this, "Item Added Successfully", Toast.LENGTH_SHORT).show();
    }

    private void deleteItem() {
        // Retrieve the item ID from the EditText
        int itemId = Integer.parseInt(itemIdEditText.getText().toString().trim());

        // Delete the item from the database
        dbHelper.deleteItem(itemId);
        Toast.makeText(this, "Item Deleted Successfully", Toast.LENGTH_SHORT).show();
    }
}
