package com.example.inventory;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database name and version
    private static final String DATABASE_NAME = "inventory.db";
    private static final int DATABASE_VERSION = 1;

    // Table name and columns
    private static final String TABLE_ITEMS = "items";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_DESCRIPTION = "description";
    private static final String COLUMN_CATEGORY = "category";
    private static final String COLUMN_QUANTITY_AVAILABLE = "quantity_available";
    private static final String COLUMN_QUANTITY_RESERVED = "quantity_reserved";
    private static final String COLUMN_LOCATION = "location";
    private static final String COLUMN_UNIT_PRICE = "unit_price";
    private static final String COLUMN_FIRST_NAME = "firstname";
    private static final String COLUMN_LAST_NAME = "lastname";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";
    private static final String TABLE_USERS = "users";


    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create the table
        String CREATE_ITEMS_TABLE = "CREATE TABLE " + TABLE_ITEMS +
                "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY," +
                COLUMN_NAME + " TEXT," +
                COLUMN_DESCRIPTION + " TEXT," +
                COLUMN_CATEGORY + " TEXT," +
                COLUMN_QUANTITY_AVAILABLE + " INTEGER," +
                COLUMN_QUANTITY_RESERVED + " INTEGER," +
                COLUMN_LOCATION + " TEXT," +
                COLUMN_UNIT_PRICE + " REAL" +
                ")";
        db.execSQL(CREATE_ITEMS_TABLE);

        // Create the users table
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS +
                "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY," +
                COLUMN_FIRST_NAME + " TEXT," +
                COLUMN_LAST_NAME + " TEXT," +
                COLUMN_USERNAME + " TEXT," +
                COLUMN_PASSWORD + " TEXT" +
                ")";
        db.execSQL(CREATE_USERS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
        // Create tables again
        onCreate(db);
    }

    // Method to add an item
    public long addItem(String name, String description, String category, int quantityAvailable, int quantityReserved, String location, double unitPrice) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_DESCRIPTION, description);
        values.put(COLUMN_CATEGORY, category);
        values.put(COLUMN_QUANTITY_AVAILABLE, quantityAvailable);
        values.put(COLUMN_QUANTITY_RESERVED, quantityReserved);
        values.put(COLUMN_LOCATION, location);
        values.put(COLUMN_UNIT_PRICE, unitPrice);
        long id = db.insert(TABLE_ITEMS, null, values);
        db.close();
        return id;
    }

    // Method to get all inventory items
    @SuppressLint("Range")
    public List<InventoryItem> getAllInventoryItems() {
        List<InventoryItem> inventoryItems = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_ITEMS, null);

        if (cursor.moveToFirst()) {
            do {
                InventoryItem item = new InventoryItem();
                item.setId(cursor.getInt(cursor.getColumnIndex(COLUMN_ID)));
                item.setName(cursor.getString(cursor.getColumnIndex(COLUMN_NAME)));
                item.setDescription(cursor.getString(cursor.getColumnIndex(COLUMN_DESCRIPTION)));
                item.setCategory(cursor.getString(cursor.getColumnIndex(COLUMN_CATEGORY)));
                item.setQuantityAvailable(cursor.getInt(cursor.getColumnIndex(COLUMN_QUANTITY_AVAILABLE)));
                item.setQuantityReserved(cursor.getInt(cursor.getColumnIndex(COLUMN_QUANTITY_RESERVED)));
                item.setLocation(cursor.getString(cursor.getColumnIndex(COLUMN_LOCATION)));
                item.setUnitPrice(cursor.getDouble(cursor.getColumnIndex(COLUMN_UNIT_PRICE)));

                inventoryItems.add(item);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();

        return inventoryItems;
    }

    // Method to update an item
    public int updateItem(int id, String name, String description, String category, int quantityAvailable, int quantityReserved, String location, double unitPrice) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_DESCRIPTION, description);
        values.put(COLUMN_CATEGORY, category);
        values.put(COLUMN_QUANTITY_AVAILABLE, quantityAvailable);
        values.put(COLUMN_QUANTITY_RESERVED, quantityReserved);
        values.put(COLUMN_LOCATION, location);
        values.put(COLUMN_UNIT_PRICE, unitPrice);
        return db.update(TABLE_ITEMS, values, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
    }

    // Method to delete an item
    public int deleteItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_ITEMS, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE username=? AND password=?", new String[]{username, password});
        int count = cursor.getCount();
        cursor.close();
        return count > 0;
    }


    // Add a new user to the database with first name, last name, username, and password
    public long addUser(String firstName, String lastName, String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_FIRST_NAME, firstName);
        values.put(COLUMN_LAST_NAME, lastName);
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);
        long id = db.insert(TABLE_USERS, null, values);
        db.close();
        return id;
    }



}
