package com.example.inventory;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class InventoryAdapter extends BaseAdapter {

    private Context context;
    private List<InventoryItem> inventoryItems;

    public InventoryAdapter(Context context, List<InventoryItem> inventoryItems) {
        this.context = context;
        this.inventoryItems = inventoryItems;
    }

    @Override
    public int getCount() {
        return inventoryItems.size();
    }

    @Override
    public Object getItem(int position) {
        return inventoryItems.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;

        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.activity_inventory_display, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.textViewItemName = convertView.findViewById(R.id.textTitle);

            // Add more TextViews for other inventory item attributes here
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        // Set data to views
        InventoryItem item = inventoryItems.get(position);
        viewHolder.textViewItemName.setText(item.getName());
        // Set other attributes here

        return convertView;
    }

    private static class ViewHolder {
        TextView textViewItemName;
        // Add more TextViews for other inventory item attributes here
    }
}

