package com.example.inventory;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class CreateAccountActivity extends AppCompatActivity {

    // Define TAG constant
    private static final String TAG = "CreateAccountActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.createaccountactivity);

        EditText firstNameEditText = findViewById(R.id.firstNameEditText);
        EditText lastNameEditText = findViewById(R.id.lastNameEditText);
        EditText usernameEditText = findViewById(R.id.usernameEditText);
        EditText passwordEditText = findViewById(R.id.passwordEditText);
        Button createAccountButton = findViewById(R.id.createAccountButton);

        createAccountButton.setOnClickListener(v -> {
            String firstName = firstNameEditText.getText().toString().trim();
            String lastName = lastNameEditText.getText().toString().trim();
            String username = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();

            // Check if any field is empty
            if (firstName.isEmpty() || lastName.isEmpty() || username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Call method to add user to database
            addUserToDatabase(firstName, lastName, username, password);
        });
    }

    private void addUserToDatabase(String firstName, String lastName, String username, String password) {
        // Add user to the database
        try (DatabaseHelper dbHelper = new DatabaseHelper(this)) {
            long result = dbHelper.addUser(firstName, lastName, username, password);

            // Check if the user was successfully added
            if (result != -1) {
                // Show success message after adding user
                Toast.makeText(this, "Account created successfully", Toast.LENGTH_SHORT).show();

                // Redirect the user to the InventoryDisplayActivity
                Intent intent = new Intent(CreateAccountActivity.this, InventoryDisplayActivity.class);
                startActivity(intent);

                // Finish current activity
                finish();
            } else {
                // Show error message if user creation failed
                Toast.makeText(this, "Failed to create account", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            // Handle any exceptions
            Log.e(TAG, "Exception occurred", e);
        }
    }
}
